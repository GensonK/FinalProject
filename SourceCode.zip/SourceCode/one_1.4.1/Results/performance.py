import pandas as pd
from queue import LifoQueue

#filename = './Dijkstra.txt'
filename = './AStar.txt'
file = open(filename, "r")

maxComp = 5
count = 0
coorFrom=[]
coorTo = []
path = []
line = file.readline()
while count<maxComp:
    if "from" in line:
        p = line.replace("Nt2@", "").replace("\n","").split(" ")
        coorFrom.append(p[1])
        coorTo.append(p[3])
        line = file.readline()
    else:
        temp=""
        while 1:
            if "from" in line:
                break
            parse = line.replace("\n","")
            temp=temp+parse
            line = file.readline()
        temp.replace('->', "", 1)
        path.append(temp.split("->"))
        del(path[count][0])
        count= count+1

print("Read Algorithm done!!!")


path_colname=['from','to','pre'];
paths = pd.read_csv('./simpleFloyd.csv',header=None,names=path_colname )
paths.set_index('from',inplace=False)
for i in range(0,5):
    start = coorFrom[i]
    end = coorTo[i]
    check = paths[(paths['from'].isin([start])&paths['to'].isin([end]))]
    comp = LifoQueue()
    comp.put(end)
    while not check.empty:
        comp.put(check['pre'].iloc[0])
        end = check['pre'].iloc[0]
        check = paths[(paths['from'] == start) & (paths['to'] == end)]
    pathCompare =[]
    while not comp.empty():
        pathCompare.append(comp.get())
    if path[i]==pathCompare:
        print("the same!!")
        print("from "+start+" to "+end)
        print(path[i])
        print(pathCompare)






