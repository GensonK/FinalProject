/* 
 * Copyright 2010 Aalto University, ComNet
 * Released under GPLv3. See LICENSE.txt for details. 
 */
package movement;

import java.util.List;
import java.io.*;

import movement.map.AStarPathFinder;
import movement.map.DijkstraPathFinder;
import movement.map.MapNode;
import movement.map.PointsOfInterest;
import core.Settings;
/**
 * Map based movement model that uses Dijkstra's algorithm to find shortest
 * paths between two random map nodes and Points Of Interest
 */
public class ShortestPathMapBasedMovement extends MapBasedMovement implements 
	SwitchableMovement {
	private static int count = 0;
	/** the Dijkstra shortest path finder */
	private DijkstraPathFinder pathFinder;
	private AStarPathFinder AStarPathFinder;
	/** Points Of Interest handler */
	private PointsOfInterest pois;
	
	/**
	 * Creates a new movement model based on a Settings object's settings.
	 * @param settings The Settings object where the settings are read from
	 */
	public ShortestPathMapBasedMovement(Settings settings) {
		super(settings);
		this.pathFinder = new DijkstraPathFinder(getOkMapNodeTypes());
		this.AStarPathFinder = new AStarPathFinder(getOkMapNodeTypes());
		this.pois = new PointsOfInterest(getMap(), getOkMapNodeTypes(),
				settings, rng);
	}

	/**
	 * Copyconstructor.
	 * @param mbm The ShortestPathMapBasedMovement prototype to base 
	 * the new object to 
	 */
	protected ShortestPathMapBasedMovement(ShortestPathMapBasedMovement mbm) {
		super(mbm);
		this.pathFinder = mbm.pathFinder;
		this.AStarPathFinder = mbm.AStarPathFinder;
		this.pois = mbm.pois;
		this.count = 0;
	}
	
	@Override
	public Path getPath() {
		Path p = new Path(generateSpeed());
		Path a = new Path(generateSpeed());
		MapNode to = pois.selectDestination();

		long DijBegin = System.currentTimeMillis();
		List<MapNode> nodePath = pathFinder.getShortestPath(lastMapNode, to);
		long DijEnd = System.currentTimeMillis();

		long ABegin = System.currentTimeMillis();
		List<MapNode> astarPath = AStarPathFinder.getShortestPath(lastMapNode, to);
		long AEnd = System.currentTimeMillis();

		// this assertion should never fire if the map is checked in read phase

		assert nodePath.size() > 0 : "No path from " + lastMapNode + " to " +
				to + ". The simulation map isn't fully connected @dijkstar";
		assert astarPath.size() > 0 : "No path from " + lastMapNode + " to " +
				to + ". The simulation map isn't fully connected @astar";
		for (MapNode node : nodePath) { // create a Path from the shortest path
			p.addWaypoint(node.getLocation());
		}
		for (MapNode node : astarPath) { // create a Path from the shortest path
			a.addWaypoint(node.getLocation());
		}
		try{
			File file1 =new File("./Results/Dijkstra.txt");
			File file2 =new File("./Results/AStar.txt");
			File file3 =new File("./Results/DijTime.txt");
			File file4 =new File("./Results/ATime.txt");
			if(!file1.exists()){
				file1.createNewFile();
			}
			if(!file2.exists()){
				file2.createNewFile();
			}
			if(!file3.exists()){
				file3.createNewFile();
			}
			if(!file4.exists()){
				file4.createNewFile();
			}

			FileWriter fw1 = new FileWriter(file1,true);
			FileWriter fw2 = new FileWriter(file2,true);
			FileWriter fw3 = new FileWriter(file3,true);
			FileWriter fw4 = new FileWriter(file4,true);
			BufferedWriter bw1 = new BufferedWriter(fw1);
			BufferedWriter bw2 = new BufferedWriter(fw2);
			BufferedWriter bw3 = new BufferedWriter(fw3);
			BufferedWriter bw4 = new BufferedWriter(fw4);

			bw3.write((DijEnd-DijBegin)+"\n");//record the time spent
			bw4.write((AEnd-ABegin)+"\n");
			bw3.close();
			bw4.close();

			bw1.write("from "+ lastMapNode+" to " + to.toString()+"\n");
			bw2.write("from "+ lastMapNode+" to " + to.toString()+"\n");
			lastMapNode = to;
			bw1.write(p.toString()+"\n");
			bw2.write(a.toString()+"\n");
			bw1.close();
			bw2.close();

			this.count ++;
			System.out.println(this.count);
		}catch(IOException ioe) {
			System.out.println("Exception occurred:");
			ioe.printStackTrace();
		}
		return p;

	}	
	
	@Override
	public ShortestPathMapBasedMovement replicate() {
		return new ShortestPathMapBasedMovement(this);
	}

}
