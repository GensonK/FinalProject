package movement;

import core.Coord;

import java.util.ArrayList;
import java.util.List;

public class NodePath {
    /** coordinates of the path */
    private List<Coord> coords;
    private List<Integer> npath;
    private Coord desCoord;
    private int desNode;
    private int nextWpIndex;

    /**
     * Creates a path with zero speed.
     */
    public NodePath(Coord co1, Coord co2, int node1, int node2) {
        this.nextWpIndex = 0;
        this.coords = new ArrayList<Coord>();
        this.npath = new ArrayList<Integer>();
        this.desCoord = co2;
        this.desNode = node2;
        addWaypoint(co1, node1);

    }

    /**
     * Copy constructor. Creates a copy of this path with a shallow copy of
     * the coordinates and speeds.
     * @param path The path to create the copy from
     */
    public NodePath(NodePath path) {
        this.nextWpIndex = path.nextWpIndex;
        this.coords = new ArrayList<Coord>((ArrayList<Coord>)path.coords);
        this.npath = new ArrayList<Integer>((ArrayList<Integer>)path.npath);
    }

    /**
     * Returns a reference to the coordinates of this path
     * @return coordinates of the path
     */
    public List<Coord> getCoords() {
        return this.coords;
    }
    public List<Integer> getNodePath() {
        return this.npath;
    }

    /**
     * Adds a new waypoint to the end of the path.
     * @param wp The waypoint to add
     */
    public void addWaypoint(Coord wp, int np) {
        this.coords.add(wp);
        this.npath.add(np);
    }



    /**
     * Returns the next waypoint on this path
     * @return the next waypoint
     */
    public Coord getNextWaypoint() {
        assert hasNext() : "Path didn't have " + (nextWpIndex+1) + ". waypoint";
        return coords.get(nextWpIndex++);
    }

    /**
     * Returns true if the path has more waypoints, false if not
     * @return true if the path has more waypoints, false if not
     */
    public boolean hasNext() {
        return nextWpIndex < this.coords.size();
    }

    /**
     * Returns the speed towards the next waypoint (asked with
     * {@link #getNextWaypoint()}.
     * @return the speed towards the next waypoint
     */
    /**
     * Returns a string presentation of the path's coordinates
     * @return Path as a string
     */
    public String toString() {
        String s ="";
        for (int i=0, n=coords.size(); i<n; i++) {
            Coord c = coords.get(i);
            s+= "->" + c;
            s += String.format("@%.2f ");
        }
        return s;
    }

}
