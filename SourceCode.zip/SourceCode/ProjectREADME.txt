**************************
This README file is intended to give you a clearer picture of the overall project
**************************

The project is compiled by the command:
.\compile

The project is run by the command:
.\one ./wdm_settings/ShortestPathMapBasedMovement.txt


Floyd algorithm was implemented in  /movement/MapBasedMovement.java
Dijkstra algorithm was implemented in /movement/map/DijPathFinder.java
A* algorithm was implemented in /movement/map/AStarPathFinder.java

*.wkt is in the folder: /data/

all the results as output of all three algorithms are stored in the folder: /Results/
and performance.py in the folder is the script for algorithm performance testing

For speed, Floyd's algorithm is commented out and not called right away. 
You can run Floyd's algorithm by removing the comment marker

more detailed information is given from README.txt, which is the original README of One